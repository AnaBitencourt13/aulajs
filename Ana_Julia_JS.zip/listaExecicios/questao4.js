/*Para cada conjunto de valores abaixo, escreva o código em JavaScript usando laço(s)
onde na opção a é para ordenar o array de forma crescente e no caso do segundo, a
letra b é de forma decrescente.
a) 10 9 8 7 6 5 4 3 2 1
b) 0 1 4 9 16 25 36 49 64 81 100*/

var crescente = [10, 9, 8, 7, 6, 5, 4, 3, 2, 1];
console.log("Array em ordem Crescente!")
console.log(crescente[9]); 
console.log(crescente[8]);
console.log(crescente[7]);
console.log(crescente[6]);
console.log(crescente[5]);
console.log(crescente[3]);
console.log(crescente[2]);
console.log(crescente[1]);
console.log(crescente[0]);


var decrescente = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100];
console.log("Array em ordem Decrescente!")
console.log(decrescente[10]); 
console.log(decrescente[9]);
console.log(decrescente[8]);
console.log(decrescente[7]);
console.log(decrescente[6]);
console.log(decrescente[5]);
console.log(decrescente[4]);
console.log(decrescente[3]);
console.log(decrescente[2]);
console.log(decrescente[1]);
console.log(decrescente[0]);
